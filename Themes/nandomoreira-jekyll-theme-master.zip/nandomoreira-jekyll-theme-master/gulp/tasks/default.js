/*
 * gulp default
 */

var gulp = require('gulp');

gulp.task('default', ['serve', 'jekyll']);