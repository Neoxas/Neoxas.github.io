/**
 * by Fernando Moreira | nandomoreira.me
 * https://github.com/nandomoreirame/nandomoreirame.github.io
 */

//=require ../../bower/jquery/dist/jquery.min.js
//=require ../../bower/classie/classie.js
//=require ../../bower/simple-jekyll-search/dest/jekyll-search.js
//=require ../../bower/swipebox/src/js/jquery.swipebox.min.js

//=require scripts/_modal.js
//=require scripts/_simple-jekyll-search.js
//=require scripts/_disqus.js
//=require scripts/_main.js
