---
layout: "writing_by_category"
category: "cat02"
permalink: "/writing/category/cat02/"
---