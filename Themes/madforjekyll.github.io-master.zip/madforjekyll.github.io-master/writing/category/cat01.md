---
layout: "writing_by_category"
category: "cat01"
permalink: "/writing/category/cat01/"
---